#include "Animal.h" // Animal.h 헤더파일 참조
using namespace std;// std를 사용하지 않아도 됨

// main.cpp에서 Animal의 생성자와 소멸자가 호출되지만
// 조건 출력을 맞추기 위해서 내용은 작성하지 않는다.
Animal::Animal(){
}

Animal::~Animal(){
}
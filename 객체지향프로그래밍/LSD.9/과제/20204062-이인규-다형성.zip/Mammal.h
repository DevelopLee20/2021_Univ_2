#include "Animal.h" // Animal.h 헤더파일 참조

class Mammal : public Animal{   // Mammal 클래스 생성
public:
};